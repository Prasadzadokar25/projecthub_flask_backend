class ImageConstant {
  static String imgManattendingonlinemeeting =
      'assets/images/img_manattendingonlinemeeting.png';

  static String imgEllipse30 = 'assets/images/img_ellipse30.png';

  static String imgIcStop = 'assets/images/img_ic_stop.svg';

  static String imgGroupDeepOrange5003 =
      'assets/images/img_group_deep_orange_50_03.svg';

  static String imgWritinghandgesture =
      'assets/images/img_writinghandgesture.png';

  static String imgPaper1 = 'assets/images/img_paper1.png';

  static String imgSearchGray600 = 'assets/images/img_search_gray_600.svg';

  static String imgFrameGray400 = 'assets/images/img_frame_gray_400.svg';

  static String imgArrowleft = 'assets/images/img_arrowleft.svg';

  static String imgShootingstar1 = 'assets/images/img_shootingstar1.png';

  static String imgEmail1 = 'assets/images/img_email1.png';

  static String imgMenu1 = 'assets/images/img_menu1.png';

  static String imgClose = 'assets/images/img_close.svg';

  static String imgRectangle392 = 'assets/images/img_rectangle392.png';

  static String imgIcLogout = 'assets/images/img_ic_logout.svg';

  static String imgEllipse34 = 'assets/images/img_ellipse34.png';

  static String imgEllipse31 = 'assets/images/img_ellipse31.png';

  static String imgIcdown = 'assets/images/img_icdown.svg';

  static String imgSearchproduct1 = 'assets/images/img_searchproduct1.png';

  static String imgMovieclapboard = 'assets/images/img_movieclapboard.png';

  static String imgFoodanddrink1 = 'assets/images/img_foodanddrink1.png';

  static String imgWritingnotes2 = 'assets/images/img_writingnotes2.png';

  static String imgCodeissue1 = 'assets/images/img_codeissue1.png';

  static String imgArrowright = 'assets/images/img_arrowright.svg';

  static String imgBusinessstartup = 'assets/images/img_businessstartup.png';

  static String imgFrame = 'assets/images/img_frame.svg';

  static String imgUser = 'assets/images/img_user.svg';

  static String imgIccommentGray400 =
      'assets/images/img_iccomment_gray_400.svg';

  static String imgIccopy = 'assets/images/img_iccopy.svg';

  static String imgIcmoreBlack900 = 'assets/images/img_icmore_black_900.svg';

  static String imgIccomment = 'assets/images/img_iccomment.svg';

  static String imgAcademiccap1 = 'assets/images/img_academiccap1.png';

  static String imgIcShow = 'assets/images/img_ic_show.svg';

  static String imgIcshare = 'assets/images/img_icshare.svg';

  static String imgMusiccd1 = 'assets/images/img_musiccd1.png';

  static String imgGroup = 'assets/images/img_group.svg';

  static String imgSocialmediama = 'assets/images/img_socialmediama.png';

  static String imgChristmasinvitationcard =
      'assets/images/img_christmasinvitationcard.png';

  static String imgIctick = 'assets/images/img_ictick.svg';

  static String imgJobsecurity1 = 'assets/images/img_jobsecurity1.png';

  static String imgDeveloper1 = 'assets/images/img_developer1.png';

  static String imgEllipse32 = 'assets/images/img_ellipse32.png';

  static String imgLaughingemoji1 = 'assets/images/img_laughingemoji1.png';

  static String imgBlueberry1 = 'assets/images/img_blueberry1.png';

  static String imgPersonalinformation =
      'assets/images/img_personalinformation.png';

  static String imgIcdelete = 'assets/images/img_icdelete.svg';

  static String imgIcprofileBlack900 =
      'assets/images/img_icprofile_black_900.svg';

  static String imgBrightnessBlack900 =
      'assets/images/img_brightness_black_900.svg';

  static String imgBusinessidea1 = 'assets/images/img_businessidea1.png';

  static String imgIcclockbold = 'assets/images/img_icclockbold.svg';

  static String imgPuzzlealert1 = 'assets/images/img_puzzlealert1.png';

  static String imgIcclockboldBlack900 =
      'assets/images/img_icclockbold_black_900.svg';

  static String imgSearch = 'assets/images/img_search.svg';

  static String imgMobilephone1 = 'assets/images/img_mobilephone1.svg';

  static String imgImage1 = 'assets/images/img_image1.png';

  static String imgSuccessstory1 = 'assets/images/img_successstory1.png';

  static String imgEdit = 'assets/images/img_edit.svg';

  static String imgLoveletter1 = 'assets/images/img_loveletter1.png';

  static String imgIcuser = 'assets/images/img_icuser.svg';

  static String imgRectangle39240x81 =
      'assets/images/img_rectangle392_40x81.png';

  static String imgCheckmark = 'assets/images/img_checkmark.svg';

  static String imgImagesendingviachat =
      'assets/images/img_imagesendingviachat.png';

  static String imgChatbot1 = 'assets/images/img_chatbot1.png';

  static String imgIcsend = 'assets/images/img_icsend.svg';

  static String imgBag1 = 'assets/images/img_bag1.png';

  static String imgIcprofile = 'assets/images/img_icprofile.svg';

  static String imgIcmore = 'assets/images/img_icmore.svg';

  static String imgBirthdaycake1 = 'assets/images/img_birthdaycake1.png';

  static String imgIcprivacypolicy = 'assets/images/img_icprivacypolicy.svg';

  static String imgGiftbox1 = 'assets/images/img_giftbox1.png';

  static String imgEarth1 = 'assets/images/img_earth1.png';

  static String imgSpalash = 'assets/images/img_spalash.svg';

  static String imgIccamera = 'assets/images/img_iccamera.svg';

  static String imgIchelp = 'assets/images/img_ichelp.svg';

  static String imgList1 = 'assets/images/img_list1.png';

  static String imgBrightness = 'assets/images/img_brightness.svg';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
