import 'package:ai_app_flutter/core/app_export.dart';

class ApiClient extends GetConnect {}
