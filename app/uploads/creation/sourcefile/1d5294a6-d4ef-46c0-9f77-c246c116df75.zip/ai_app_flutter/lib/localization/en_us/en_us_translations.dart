final Map<String, String> enUs = {
  'msg_network_err': 'Network Error',
  'msg_something_went_wrong': 'Something Went Wrong!',
  "lbl_continue": "Continue",
  "lbl_public_inter": " : Public inter\n",
  "msg_initialize_curl_ch":
      "// Initialize curl \$ch = curl_init();  // Set the URL curl_setopt(\$ch, CURLOPT_URL, \"http://example.com/api\");  // Set the HTTP method curl_setopt(\$ch, CURLOPT_HTTPGET, true);  // Execute the request and get the response \$response = curl_exec(\$ch);\n\n// Set the URL  ",
  "msg_plagiarism_checker": "Plagiarism Checker",
  "lbl_history_empty": "History empty",
  "lbl_logout": "Logout",
  "lbl_email_address": "Email address",
  "msg_give_me_a_short2":
      "Give me a short conversation\n between scussing quantum physics. ",
  "lbl_poems": "Poems",
  "msg_how_to_close_thinkbotAIai": "How to close aiBotTalk account?",
  "lbl_reset_password": "Reset password",
  "lbl_about": "About",
  "msg_don_t_have_an_account": "Don’t have an account?",
  "msg_idea_of_denouncing": " idea of denouncing pleasure and ",
  "msg_give_me_a_crud_function":
      "Give me a CRUD function in Python\n programming language",
  "msg_write_an_academic3":
      "Write an academic essay about the ethics of artifical intelligence.",
  "msg_lorem_ipsum_dolor2":
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.",
  "lbl_new_password": "New password",
  "lbl_diet_plan": "Diet plan",
  "msg_write_an_academic2":
      "Write an academic essay about the role of technology in shaping.",
  "msg_what_s_the_most":
      "What's the most interesting thing you've read lately?\nWhat's a fact about you that's not on the internet?\nDo you listen to any podcasts? ...\nIf you were in charge of the playlist, which song would you play next?\nWhat's the best gift you've ever gotten?\nWhat's the most interesting thing you've read lately?\nWhat's a fact about you that's not on the internet?\nDo you listen to any podcasts? ...\nIf you were in charge of the playlist, which song would you play next?\nWhat's the best gift you've ever gotten?",
  "lbl_app_navigation": "App Navigation",
  "msg_writing_tab_container": "Writing - Tab Container",
  "msg_give_me_a_script":
      "Give me a script for a comedy set\n in an amusement park",
  "lbl_general": "General",
  "msg_have_to_be_repudiated":
      "Have to be repudiated and aects pleasures to secure other greater pleasures, or else he endures pains to avoid worse pains.\"",
  "msg_check_your_app_s":
      "Check your app's UI from the below demo screens of your app.",
  "lbl_log_out_popup": "Log out popup",
  "msg_as_designers_attempting":
      "As designers attempting to creating functional work, oftentimes we are required to make our designs look as finished as possible. For the example, if you are designing a brand.",
  "msg_this_is_one_of_the":
      "This is one of the better text generators with 10 different languages (or language styles) to generate. They also include the CSS parameters in case you are interested in styling everything correctly. Of course, the features are pretty standard with options like define the amount of words or characters and the amount of paragraphs. Example (Li Europan lingues): Li Europan lingues es membres del sam familie. Lor separat existentie es un myth. Por scientie, musica, sport etc",
  "msg_sed_ut_perspiciatis": "Sed ut perspiciatis unde omnis",
  "msg_translate_language2": "Translate language",
  "msg_and_expound_the": ", and expound the actual teachings of the great ",
  "lbl_give_me2": "Give me ",
  "msg_translate_language3": "Translate Language One",
  "msg_i_m_looking_for":
      "I'm looking for a LinkedIn post idea\n that shares a recent smer.",
  "msg_give_me_an_italian":
      "Give me an Italian food recipe that\n is low in fat and cholesterol.",
  "msg_create_your_new":
      "Create your new password. if you forget it, then you have to do forgot password.",
  "msg_i_disappointed_friends":
      "I disappointed friends by forgettin\n important appointment.",
  "msg_otp_code_varification": "otp code varification",
  "lbl_9_18_pm": "9:18 PM",
  "msg_tell_a_joke_chat": "Tell a joke chat",
  "msg_give_me_i_m_having":
      "Give me I'm having my 17th birthday, I wanted the classroom..",
  "msg_answer_interview2": "Answer interview ",
  "msg_answer_interview3": "Answer interview chat",
  "lbl_chatbook": "Chatbook",
  "lbl_movie_script": "Movie script",
  "lbl_previous_search": "Previous search",
  "msg_create_conversaion": "Create conversaion",
  "msg_can_you_explain":
      "Can you explain this code, find\n logic errors, and potential pents.",
  "lbl_last_name": "Last name",
  "msg_write_me_a_conversation":
      "Write me a conversation between 4\n people  destinations in America.",
  "lbl_44": "44%",
  "msg_write_me_a_template":
      "Write me a template email to my\n customers that",
  "lbl_history": "History",
  "msg_15_index_87":
      "15% : Index\n87% : mans\n25% : Public inter\n44% : Exam papers\n\n\"But I must explain to you how all this mistaken idea of denouncing pleasure and praising pain was born and I will give you a complete account of the system, and expound the actual teachings of the great explorer of the truth, the master-builder of human happiness",
  "msg_answer_interview": "Answer interview",
  "lbl_email_writer": "Email writer",
  "msg_as_designers_attempting2":
      "As designers attempting to creating functional work, oftentimes we are required to make our designs look as finished as possible. For example, if you are designing a brand new website for someone, most times you will have to make sure the prototype looks finished by inserting text or photos or what have you. The purpose of this is so the person viewing the prototype has a chance to actually feel and understand the idea behind what you have created.",
  "msg_this_is_it_hard": "This Is it hard to read a movie script?",
  "msg_this_was_ranked":
      "(This was ranked #1): A woman gets on a bus with her baby. The bus driver says: “Ugh, that’s the ugliest baby I’ve ever seen!” The woman walks to the rear of the bus and sits down, fuming. She says to a man next to her: “The driver just insulted me!” The man says: “You go up there and tell him off. Go on, I’ll hold your monkey for you.”\nI said to the Gym instructor “Can you teach me to do the splits?” He said, “How flexible are you?” I said, “I can’t make Tuesdays.”\nPolice arrested two kids yesterday, one was drinking battery acid, the other was eating fireworks. They charged one – and let the other one off.\nDoc, I can’t stop singing the ‘Green Green Grass of Home’. He said: “That sounds like Tom Jones syndrome.” “Is it common?” I asked. “It’s not unusual” he replied.\nI’m on a whiskey diet. I’ve lost three days already.\nMy therapist says I have a preoccupation with vengeance. We’ll see about that.\nA priest, a rabbi and a vicar walk into a bar. The barman says, “Is this some kind of joke?”\nA group of chess enthusiasts checked into a hotel and were standing in the lobby discussing their recent tournament victories. After about an hour, the manager came out of the office and asked them to disperse. “But why?” they asked, as they moved off. “because,” he said “I can’t stand chess nuts boasting in an open foyer.”\nI was in Tesco’s and I saw this man and woman wrapped in a barcode. I said, “Are you two an item?”\nI was having dinner with Garry Kasporov (world chess champion) and there was a check tablecloth. It took him two hours to pass me the salt.",
  "lbl_system": "system",
  "msg_what_is_thinkbotai": "What is aiBotTalk?",
  "msg_login_successful": "Login successful!",
  "lbl_invitation_chat": "Invitation chat",
  "msg_my_apology_and_my":
      "My apology and my apologies are both correct, but they are used differently in sentences. My apologies is a way to say you're sorry about something. My apology is a reference to a previous apology you made\nMy apology and my apologies are both correct, but they are used differently in sentences. My apologies is a way to say you're sorry about something. My apology is a reference to a previous apology you made\nMy apology and my apologies are both correct, but they are used differently in sentences. My apologies is a way to say you're sorry about something. My apology is a reference to a previous apology you made\nMy apology and my apologies are both correct, but they are used differently in sentences. My apologies is a way to say you're sorry about something. My apology is a reference to a previous apology you made",
  "lbl_password": "Password",
  "lbl_storyteller": "Storyteller",
  "lbl_pain_was": " pain was ",
  "msg_please_enter_your": "Please enter your email & password to log in.",
  "lbl_bessie": "Bessie",
  "lbl_birthday_chat": "Birthday chat",
  "msg_rebound_to_ensue":
      "Rebound to ensue; and equal blame belongs to those who fail in their duty through weakness of will, which is the same as saying through shrinking from toil and pain. These cases are perfectly simple and easy to distinguish. In a free hour, when our power of choice is untrammelled and when nothing prevents our being able to do what we like best, every pleasure is trust.",
  "msg_can_the_you_help2":
      "Can the you help me develop a\n LinkedIn post idea that features ",
  "lbl_birthday": "Birthday",
  "msg_songs_lyrics_one": "Songs/Lyrics One",
  "msg_give_me_a_short":
      "Give me a short but interesting job\n post for a researcher ",
  "lbl_not_found": "Not found",
  "lbl_start_chat": "Start chat",
  "msg_start_chatting_with":
      "Start chatting with aiBotTalk now. You can ask me anything.",
  "msg_these_are_just_a": "These are just a few examples of what i can do.",
  "msg_hello_anything": "Hello, anything|",
  "lbl_complete": " complete ",
  "msg_how_do_i_start_writing": "How do I start writing code?",
  "msg_academic_articles": "Academic Articles",
  "msg_give_me_dropped": "Give me dropped my girlfriend Angelina's birthday...",
  "lbl_25": "25%",
  "msg_how_we_use_your": "How we use your information",
  "lbl_capabilities": "Capabilities",
  "msg_write_an_articles": "Write an Articles",
  "msg_i_agree_to_thinkbotai2": "I agree to aiBotTalk",
  "lbl_chat": "Chat",
  "msg_translate_the_following":
      "Translate the following sentence \ninto english ‘consejos para..",
  "lbl_thinkbotai2": "aiBotTalk ",
  "msg_songs_lyrics_chat2": "Songs/Lyrics chat One",
  "msg_i_want_to_write2": "I want to write a poems about\n divinity",
  "msg_i_want_to_write3":
      "I want to write a poem on the\n subject of failure in life and success",
  "msg_public_agreement": "public Agreement, Terms, & Privacy Policy.",
  "msg_i_want_to_write4":
      "I want to write a short film script\n about life and friends in high school",
  "msg_locate_any_logic":
      "Locate any logic errors in the\n following [language] code snippet: ",
  "lbl_change_password": "Change password",
  "lbl_apology_chat": "Apology chat",
  "msg_i_want_to_write5":
      "I want to write an email bosscan\n not enter the office due to illness.",
  "msg_i_want_to_write6":
      "I want to write a job post for a new\n employee in my office",
  "msg_it_is_a_letter_that":
      "It is a letter that is written to invite individuals to a specific event. This can be written for a wedding, engagement, graduation, exhibition, or yearly day, among other things. It can be both a formal and informal letter. It can be addressed to a person or an organisation and authored by an individual or an entity.\nIt is a letter that is written to invite individuals to a specific event. This can be written for a wedding, engagement, graduation, exhibition, or yearly day, among other things. It can be both a formal and informal letter. It can be addressed to a person or an organisation and authored by an individual or an entity.\nIt is a letter that is written to invite individuals to a specific event. This can be written for a wedding, engagement, graduation, exhibition, or yearly day, among other things. It can be both a formal and informal letter. It can be addressed to a person or an organisation and authored by an individual or an entity.",
  "lbl_11_03_pm": "11:03 PM",
  "msg_the_my_18_th_birthday": "The my 18 th birthday was been wishesh?",
  "msg_i_agree_to_thinkbotai":
      "I agree to aiBotTalk public Agreement, Terms, & Privacy Policy.",
  "lbl_get_started": "Get started",
  "msg_generate_all_the": "Generate all the text you want.",
  "lbl_business": "Business",
  "msg_lorem_ipsum_dolor":
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor...",
  "lbl_sign_up": "Sign up",
  "msg_stop_generating": "Stop generating...",
  "lbl_15": "15%",
  "msg_i_have_a_salon_service":
      "I have a salon service, give me\n advertising words for marketing.",
  "msg_explain_code_chat": "Explain code chat",
  "msg_create_conversation": "Create conversation",
  "msg_the_birthday_wishing": "The birthday wishing message",
  "msg_give_me_toggle_to": "Give me toggle to use Video  Instagram online?",
  "lbl_developer": "Developer",
  "lbl_skip": "Skip",
  "lbl_privacy_policy": "Privacy policy",
  "lbl_ai_assistants": "AI Assistants",
  "msg_i_want_to_make_a":
      " I want to make a song with the\n theme of true friends",
  "lbl_songs_lyrics": "Songs/lyrics",
  "lbl_spalash": "Spalash     ",
  "msg_plagiarism_checker3": "Plagiarism checker chat",
  "lbl_account_of_the": "account of the ",
  "lbl_save": "Save",
  "msg_can_the_you_help":
      "Can the you help me develop a\n Write me a sincere wish for.",
  "msg_i_want_to_make_a3":
      "I want to make a dinner party with\n high school invitation to give them.",
  "msg_plagiarism_checker2": "Plagiarism checker",
  "msg_i_want_to_make_a2":
      "I want to make a short novel story\n about a friendship in high school",
  "msg_give_me_a_recipe":
      "Give me a recipe for making\n Korean oriental Pajeon spicy.",
  "lbl_writing": "Writing",
  "msg_these_cases_are":
      "These cases are perfectly simple and easy to distinguish. ",
  "msg_write_me_a_cover":
      "Write me a cover letter for the\n Product Designer position at Google ",
  "lbl_log_in2": "Log in",
  "msg_how_to_use_video": "How to use video Downloader for Instagram online?",
  "msg_ask_me_anything": "Ask me anything...",
  "msg_what_is_a_good_sentence": "What is a good sentence for advertisement?",
  "msg_and_i_will_give": " and I will give you a",
  "lbl_praising": "praising",
  "lbl_job_post": "Job post",
  "msg_bessiecooper_gmail_com": "bessiecooper@gmail.com",
  "msg_write_an_article3":
      "Write an article discussing the \nimportance of maintaining.",
  "msg_what_is_the_level":
      "   What is the level of originality of this essay ‘one of the ways",
  "msg_write_an_article2":
      "Write an article discussing the \nimpact of climate change on the ",
  "msg_what_is_a_storyteller": " What is a storyteller role?",
  "lbl_thinkbot_ai": "aiBotTalk AI",
  "msg_give_me_a_recipe2":
      "Give me a recipe for making japanis and joke about..",
  "msg_make_me_a_poems":
      "   Make me a poems with the theme\n of justice and social criticism",
  "msg_do_me_a_two_person":
      "Do me a two person conversation\n between John Lily about attending.",
  "msg_is_my_apology_correct": "Is my apology correct?",
  "msg_create_new_password": "Create new password",
  "lbl_born": "born",
  "lbl_welcome_back": "Welcome back",
  "msg_though_it_will":
      "\"Though it will never be easy, learning how to read a screenplay properly can make things a little easier. To prepare for an audition, you need an open mind, an analytical eye, perseverance, and extensive practice. Here are the tips and techniques you'll need to read a script and bring your best on audition day.ndis doloribus asperiores repellat.\"Though it will never be easy, learning how to read a screenplay properly can make things a little easier. To prepare for an audition, you need an open mind, an analytical eye, perseverance, and extensive practice. Here are the tips and techniques you'll need to read a script and bring your best on audition day.",
  "msg_boiling_results":
      "Boiling results in the greatest loss of nutrients, while other cooking methods more effectively preserve the nutrient content of food. Steaming, roasting and stir-frying are some of the best methods of cooking vegetables when it comes to retaining nutrientsthe rice vinegar, sugar, and salt until the sugar and salt have dissolved.\nOnce the rice is cooked, transfer it to a large bowl and add the vinegar mixture. Gently fold the rice with a wooden spoon or spatula until it is evenly coated.\nCut the nori sheets in half, and place a half sheet on a sushi mat.\nWet your hands, and take a handful of rice (about 1/2 cup). Spread the rice over the nori, leaving about 1 inch at the top of the sheet uncovered.\nArrange the fillings in a line across the rice.\nUse the sushi mat to roll the sushi tightly, tucking the fillings in as you go. Wet the uncovered edge of the nori with water to seal the roll.\nRepeat with the remaining nori sheets and rice, until all the ingredients are used up.\nUse a sharp knife to cut the sushi rolls into bite-sized pieces.\nServe the sushi with soy sauce, wasabi, and pickled ginger.\n\nEnjoy your homemade sushi!",
  "lbl_hii_there": "Hii, there!",
  "msg_chat_screen_stop": "Chat screen Stop generating",
  "msg_translate_language": "Translate Language",
  "msg_write_me_a_heartfelt":
      "Write me a heartfelt wish for my\n daughter's 12th birthday",
  "msg_academic_writer": "Academic Writer chat",
  "msg_how_can_i_log_out": "How can I log out from aiBotTalkAI?",
  "msg_how_long_can_twitter": "How long can twitter videos been  2023?",
  "lbl_hello_sir": "Hello, sir",
  "lbl_food_recipes": "Food Recipes",
  "msg_linkedin_a_profile2": "LinkedIn a profile or fb account the blog?",
  "lbl_apology": "Apology",
  "msg_linkedin_a_profile": "LinkedIn a profile or account the want blog?",
  "lbl_explain_code": "Explain code",
  "msg_home_one_container": "Home One - Container",
  "lbl_job_post_chat": "Job post chat",
  "msg_short_sweet_happy": "Short & Sweet Happy Birthday Messages.",
  "lbl_devloper": "Devloper",
  "lbl_next": "Next",
  "msg_i_want_to_eat_a":
      "I want to eat a salad, give me a\n simple salad recipe with the main. ",
  "lbl_invitation": "Invitation",
  "msg_put_me_on_a_nut":
      "Put me on a nut, tomato and fish\n free diet plan because them.",
  "msg_hope_all_your_birthday":
      "Hope all your birthday wishes come true.\nYou bring light and love into my life. ...\nForget the past; look forward to the future, for the best things are yet to come.\nLife is a journey. ...\nHappy birthday! ...\nYou have to get older, but you don't have to grow up.\nHappy moments.s!\"\nHope all your birthday wishes come true.\nYou bring light and love into my life. ...\nForget the past; look forward to the future, for the best things are yet to come.\nLife is a journey. ...\nHappy birthday! ...\nYou have to get older, but you don't have to grow up.\nHappy moments.",
  "msg_i_have_a_talk_show":
      "I have a talk show event on\n Saturday night, can I make invitation.",
  "msg_you_don_t_need_a":
      "You don't need a plagiarism checker, right? You would never copy-and-paste someone else’s work, you’re greatparaphrasing, and you always keep a tidy list of your sources handy.",
  "lbl_home": "Home",
  "msg_food_recipes_chat": "Food Recipes chat",
  "msg_i_weight_70_kg": "I weight 70 kg, i want a diet plan to success ..",
  "lbl_first_name": "First name",
  "msg_already_have_an": "Already have an account?",
  "msg_start_with_something":
      "Start with something memorable. Every social media post needs a “hook.” Begin with a brief sentence about what the job means to you. ...\nShare details of what the role entails. You are more than your job title. ...\nExpress gratitude to previous colleagues. ...\nDon't forget the basics.Start with something memorable. Every social media post needs a “hook.” Begin with a brief sentence about what the job means to you. ...\n6. Share details of what the role entails. You are more than your job title. ...\nExpress gratitude to previous colleagues. ...\nDon't forget the basics.",
  "lbl_chat_screen": "Chat screen",
  "lbl_php": "PHP",
  "msg_i_made_my_mother":
      "I made my mother angry, write me\n a sincere apology",
  "msg_i_weigh_80_kg_i":
      "I weigh 80 kg, I want a diet\n vegetables cabbage because I hateit.",
  "lbl_login_success": "login success ",
  "msg_storyteller_chat": "Storyteller chat",
  "msg_confirm_password": "Confirm password",
  "msg_the_linkedin_a_profile": "The LinkedIn a profile or account the blog?",
  "msg_are_you_sure_you": "Are you sure you want to log out?",
  "msg_we_re_sorry_the":
      "We're sorry, the keyword you were looking for could not be found. Please search with another keywords.",
  "msg_conversational_ai": "Conversational AI.",
  "lbl_give": "Give ",
  "msg_forgot_passsword": "Forgot passsword?",
  "msg_hello_how_can_i": "hello How can i help you?",
  "msg_give_me_a_joke_about": "Give me a joke about tigers wnat to go diet.",
  "msg_i_need_a_linkedin":
      "I need a LinkedIn post idea that\n showcases my programs and its uni.",
  "lbl_question": "Question",
  "msg_forgot_password": "Forgot password?",
  "lbl_hello": "Hello",
  "msg_how_to_answer_an": "How to answer an interview?",
  "msg_rebound_to_ensue2":
      "Rebound to ensue; and equal blame belongs to those who fail in their duty through weakness of will, which is the same as saying through shrinking from toil and pain. These cases are perfectly simple and easy to distinguish. In a free hour, when our power of choice is untrammelled and when nothing prevents our being able to do what we like best, every pleasure is trust.\npursue pleasure rationally encounter consequences that are extremely painful. ",
  "msg_make_me_lyrics_of": "Make me lyrics of a broken heart because of love",
  "lbl_cancel": "Cancel",
  "msg_how_california_can":
      "How California can capture stormwater to fight off the drought?",
  "lbl_academic_writer": "Academic writer",
  "lbl_edit_profile": "Edit profile",
  "msg_chat_screen_active": "Chat screen active",
  "lbl_history_delete": "History delete",
  "lbl_ai_assitants": "AI Assitants",
  "lbl_01_onboarding": "01 onboarding",
  "lbl_index": " : Index\n",
  "lbl_tell_a_joke": "Tell a joke",
  "msg_answer_all_your": "Answer all your questions.",
  "lbl_write_code_chat": "Write code chat",
  "lbl_explorer": "explorer ",
  "msg_advertisements_one": "Advertisements One",
  "msg_write_a_short_article": "Write a short article descussing",
  "lbl_advertisements": "Advertisements",
  "msg_enjoying_a_vacation":
      "Enjoying a vacation or taking a business trip to another country? You may need help communicating with the locals from time to time.",
  "msg_information_we_collect": "Information We Collect",
  "msg_i_dropped_my_girlfriend2":
      "I dropped my girlfriend Angelina's the brothers...",
  "lbl_view_all": "View all",
  "msg_examples_of_poetry":
      "Examples of poetry in this category include: allegory - a narrative poem that uses an extended metaphor to make a point. ballad - narrative poetry set to music. burlesque - a mock-epic poem that tells an ordinary story in a melodramatic way.Examples of poetry in this category include: allegory - a narrative poem that uses an extended metaphor to make a point. ballad - narrative poetry set to music. burlesque - a mock-epic poem that tells an ordinary story in a melodramatic way.Examples of poetry in this category include: allegory - a narrative poem that uses an extended metaphor to make a point. ballad - narrative poetry set to music. burlesque - a mock-epic poem that tells an ordinary story in a melodramatic way.",
  "msg_write_an_article":
      "Write an article discussing the \nbenefits of practicing mindfulness. ",
  "msg_you_can_type_in":
      "You can type in anything: a menu item, a question, or a business proposition. Instantly, you’ll have its equivalent in the target language.",
  "msg_of_the_truth_the": "of the truth, the master-builder of ",
  "msg_how_can_i_find_a": "How can I find a name of a song?",
  "msg_shazam_will_identify":
      "‘’Shazam will identify any song in seconds. Discover artists, lyrics, videos & playlists, all for free. Over 1 billion installs and counting!maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat.\"\nBut don't give up, don't lose your hope\nYou'll find love again, it's not a joke\nTake a deep breath, let it all out\nYou'll get through this, without a doubt\n\nOutro:\nIt's not the end, it's just the start\nOf a new beginning, a brand new heart\nYou'll love again, and it'll be true\nJust trust in yourself, you'll make it through.",
  "lbl_yes_logout": "Yes,  logout",
  "lbl_service": "Service",
  "msg_how_to_lose_5kg": "How to lose 5kg in 7 days diet?",
  "msg_what_is_invitation": "What is invitation in writing?",
  "msg_make_me_a_rock_song": "    Make me a rock song with an anti-war subject",
  "lbl_02_onboarding": "02 onboarding",
  "msg_please_enter_your2":
      "Please enter your email & password to create an account.",
  "msg_the_storystelled": "The storystelled and birthday.",
  "msg_please_enter_your3":
      "Please enter your email and we will send an OTP code in the next step to reset password.",
  "msg_copy_ai_is_one_of":
      "Copy AI is one of the best AI-free content generators that you can use for email writing. With CopyAI's automated creativity tools, you can generate marketing copy in seconds. Copy.ai is here to help you curate relevant email text. Our tool generates subject lines that target your audience.Copy AI is one of the best AI-free content generators that you can use for email writing. With CopyAI's automated creativity tools, you can generate marketing copy in seconds. Copy.ai is here to help you curate relevant email text. Our tool generates subject lines that target your audience.Copy AI is one of the best AI-free content generators that you can use for email writing. With CopyAI's automated creativity tools, you can generate marketing copy in seconds. Copy.ai is here to help you curate relevant email text. Our tool generates subject lines that target your audience.",
  "msg_how_can_i_use_thinkbotai": "How can I use aiBotTalk",
  "msg_funniest_jokes_ever": "Funniest Jokes Ever Told for the Joke of the Day",
  "msg_create_conversation2": "Create conversation chat",
  "msg_what_to_include": "What to include in your new job announcement",
  "msg_i_have_the_php_code":
      "I have the PHP code, but I don't\n know what it means.",
  "lbl_faq": "FAQ",
  "lbl_creative": "Creative",
  "msg_show_me_what_you": "Show me what you can do",
  "lbl_give_me": "Give me",
  "msg_how_do_i_make_an":
      "How do I make an HTTP request in\n Javascript, PHP, and Python?",
  "lbl_03_onboarding": "03 onboarding",
  "lbl_personal_info": "Personal info",
  "lbl_account": "Account",
  "msg_give_me_my_girlfriend":
      "Give me my girlfriend Angelina's the brothers...",
  "msg": "「個人的、職業的な生活において健全な人間関係を築き維持する方法」",
  "msg_what_percentage":
      "   What percentage level of the plagiarism emerges from this thesis ‘",
  "msg_give_me_advertising": "Give me advertising words",
  "msg_write_an_academic":
      "Write an academic essay about the impact of climate change on.",
  "msg_chat_screen_share": "Chat screen share popup",
  "msg_is_the_thinkbot_ai": "Is the aiBotTalk AI app free?",
  "msg_describe_the_function":
      "Describe the function of this code,\n find deadlock issues, and potential.",
  "msg_you_have_no_history": "You have no history",
  "msg_tintroducing_our":
      "TIntroducing our latest writing tool cases and the begined in the my launguage?",
  "lbl_food": "Food",
  "msg_please_wait_you":
      "Please wait...\nYou will be directed to the homepage.",
  "lbl_empty": "Empty",
  "msg_best_personal_ai": "Best Personal AI Assitant",
  "msg_what_is_a_code_explanation": "What is a code explanation?",
  "msg_i_want_a_fruit_diet":
      "I want a fruit diet plan without\n pineapple papaya for 1 full month.",
  "lbl_sign_up_fill": "Sign up fill",
  "msg_i_hope_you_like": "I hope you like crazy bond",
  "lbl_mans": " : mans\n",
  "lbl_history_one": "History One",
  "lbl_login_fill": "Login fill",
  "lbl_human_happiness": "human happiness",
  "msg_write_me_an_advertisement": "Write me an advertisement",
  "msg_what_is_the_best": "What is the best AI free email generator?",
  "lbl_social_media": "Social media",
  "msg_what_do_you_say2": "What do you say to build a the blog conversation?",
  "msg_movie_script_chat": "Movie script chat",
  "msg_the_best_ai_chatbot": "The best AI chatbot app in century",
  "msg_exam_papers_but":
      " : Exam papers\n\n\"But I must explain to you how all this ",
  "msg_lose_weight_consistently":
      "Lose weight consistently by following a calorie deficit diet—this is when you burn more calories than you intake within a day. Eat a diet that's rich in whole grains, lean protein, and fresh fruits and veggies, and aim to get 150 minutes of exercise each week.Lose weight consistently by following a calorie deficit diet—this is when you burn more calories than you intake within a day. Eat a diet that's rich in whole grains, lean protein, and fresh fruits and veggies, and aim to get 150 minutes of exercise each week.Lose weight consistently by following a calorie deficit diet—this is when you burn more calories than you intake within a day. Eat a diet that's rich in whole grains, lean protein, and fresh fruits and veggies, and aim to get 150 minutes of exercise each week.",
  "lbl_9_41_pm": "9:41 PM",
  "msg_which_is_better": "Which is better to cook food?",
  "lbl_poems_chat": "Poems chat",
  "lbl_history_two": "History Two",
  "msg_what_is_an_ad_headline":
      "What is an ad headline? An ad headline is a group of a few words or sentences that promote a product or service. Ad headlines can be in print or digital form and typically emphasize a product's primary purpose or benefit to a consumer.What is an ad headline? An ad headline is a group of a few words or sentences that promote a product or service. Ad headlines can be in print or digital form and typically emphasize a product's primary purpose or benefit to a consumer.What is an ad headline? An ad headline is a group of a few words or sentences that promote a product or service. Ad headlines can be in print or digital form and typically emphasize a product's primary purpose or benefit to a consumer.",
  "lbl": "*******|*",
  "msg_swathes_of_california":
      "Swathes of California have seen dump heavy rains since the end of December, with storms forecast to bring 75 trillion litres more over the next two weeks. The deluge is a problem – severe flooding has wreaked havoc on the San Francisco Bay Area and led to at least six deaths. But it could also offer some respite to a state in the throes of a severe water crisis driven by megadrought and overuse Swathes of California have seen dump heavy rains since the end of December, with storms forecast to bring 75 trillion litres more over the next two weeks. The deluge is a problem – severe flooding has wreaked havoc on the San Francisco Bay Area and led to at least six deaths.\nBut it could also offer some respite to a state in the throes of a severe water crisis driven by megadrought and overuse. …",
  "msg_write_thoughtful":
      "Write thoughtful essays or well-researched papers. What does Academic Writer do?",
  "lbl_cooper": "Cooper",
  "msg_make_me_a_bedtime":
      "  Make me a bedtime story about a\n girl with a magic stone",
  "msg_toggle_to_use_video": "toggle to use Video  Instagram online?",
  "msg_give_is_invitation": "Give is invitation in writing this questions?",
  "msg_which_is_better2": "Which is better to cook food of the day?",
  "lbl_mistaken": "mistaken",
  "lbl_academic_writer2": "Academic Writer",
  "msg_give_this_is_better": "Give this is better to cook food of the day?",
  "msg_i_want_to_wish_my":
      "I want to wish my mother a sincere\n happy birthday who will be 60 years.",
  "lbl_search": "Search|",
  "lbl_songs_lyrics2": "Songs/Lyrics",
  "msg_what_is_example": "What is example of poetry?",
  "lbl_87": "87%",
  "msg_code_explanation":
      "Code explanation using AI involves using machine learning algorithms and natural language processing techniques to generate human-readable explanations of code. This can help make code more accessible to non-experts, such as business stakeholders or users, and can help developers better understand complex codebases.\nCode explanation using AI involves using machine learning algorithms and natural language processing techniques to generate human-readable explanations of code. This can help make code more accessible to non-experts, such as business stakeholders or users, and can help developers better understand complex codebases.",
  "msg_i_am_droped_with": "I am droped with girlfriend with the classroom?",
  "lbl_log_out2": "Log out",
  "msg_the_give_me_the":
      "The Give me the answer to the interview the  \"What salary do yo",
  "msg_songs_lyrics_chat": "Songs/Lyrics chat",
  "msg_what_is_invitation2": "What is invitation in writing this questions?",
  "msg_what_is_the_best3": "What is the best answer to the",
  "msg_what_is_the_best2":
      "What is the best answer to the\n interview question",
  "msg_speak_clearly_and":
      "Speak clearly and vary your tone to show you're interested and enthusiastic. Take time to think about each question before answering so you can give a good response. Listen to questions carefully and let the interviewer lead the conversation. If you don't understand a question, ask for it to be explained or repeated.Speak clearly and vary your tone to show you're interested and enthusiastic. Take time to think about each question before answering so you can give a good response. Listen to questions carefully and let the interviewer lead the conversation. If you don't understand a question, ask for it to be Speak clearly and vary your tone to show you're interested and enthusiastic. Take time to think about each question before answering so you can give a good response. Listen to questions carefully and let the interviewer lead the conversation. If you don't understand a question, ask for it to be explained or repeated.explained or repeated.",
  "lbl_login": "Login",
  "lbl_remebmer_me": "Remebmer me",
  "msg_give_me_a_way_to": "Give me a way to answer the\n interview question?",
  "msg_i_m_having_my_16th":
      "I'm having my 16th birthday, I want\n to make an invitatio  friend Magie.",
  "msg_what_do_you_say": "What do you say to build a conversation?",
  "lbl_faq_s": "FAQ’s",
  "msg_various_ai_assistants": "Various AI assistants to help you more",
  "lbl_personal": "Personal",
  "msg_i_want_to_check":
      "  I want to check the plagiarism of this articals ‘social media has..",
  "msg_write_an_articles3": "Write an Articles One",
  "lbl_write_code": "Write code",
  "lbl_10_06_pm": "10:06 PM",
  "lbl_all": "All",
  "msg_try_premium_for": "Try premium for your unlimited usage",
  "msg_write_an_articles2": "Write an articles",
  "msg_an_academic_writer":
      "An Academic Writer creates college-level papers such as essays, dissertations, and theses. Technically, any college student is an Academic Writer. However if you want to make money in this position, you will write papers for someone other than yourself-which means you need to move beyond turning in the product of an all-nighter.Use your freshman paper as the first step on your path to beginning your career as a professional Academic Writer. In this position, you devote your writing to topics of interest, or to intellectual debates with other students or faculty. Research papers and other documents that express viewpoints, challenge current ideas, or induce thought-provoking dorm room chatter all fit the bill.",
  "lbl_other": "Other",
  "msg_what_does_a_storyteller":
      "What Does a Storyteller Do? As a storyteller, your job is to narrate and read stories to an audience. In many cases, this focuses on orally encouraging certain emotions or reactions in your listeners or trying to convey details about a situation. What Does a Storyteller Do? As a storyteller, your job is to narrate and read stories to an audience. In many cases, this focuses on orally encouraging certain emotions or reactions in your listeners or trying to convey details about a situation.dolorem eum fugiat quo voluptas nulla pariatur?\"What Does a Storyteller Do? As a storyteller, your job is to narrate and read stories to an audience. In many cases, this focuses on orally encouraging certain emotions or reactions in your listeners or trying to convey details about a situation.",
  "lbl_diet_plan_chat": "Diet plan chat",
  "msg_i_want_to_write":
      "I want to write a short story about\n the meaning of love and friends",
  "lbl_writing2": "Writing ",
  "msg_this_is_better_to": "this is better to cook food of the day?",
  "msg_translate_the_following2":
      "Translate the following sentence\n into german 理健康和自我保健对 ",
  "msg_translate_the_following3":
      "Translate the following sentences\n into korean ‘ impactul schimbrilor.",
  "msg_make_me_a_job_post":
      "Make me a job post with the\n position of Product Designer for..",
  "msg_i_dropped_my_girlfriend":
      "I dropped my girlfriend Sarah's\n favorite cosmetics to apologize? ",
  "msg_reset_password_successful": "Reset password successful!"
};
