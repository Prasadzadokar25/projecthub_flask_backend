import 'package:get/get.dart';

/// This class is used in the [business_item_widget] screen.

class BusinessItemModel {
  Rx<String> advertisementsTxt = Rx("Advertisements");

  Rx<String>? id = Rx("");
}
