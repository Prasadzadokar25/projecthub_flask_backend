import 'dart:ui';


class WritingModel{
  String image;
  String name;
  Color color;
  String route;

  WritingModel(this.image, this.name, this.color,this.route);
}