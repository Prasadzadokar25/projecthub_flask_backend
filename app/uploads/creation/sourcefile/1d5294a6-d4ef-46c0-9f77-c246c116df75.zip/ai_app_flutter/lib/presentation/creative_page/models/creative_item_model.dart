import 'package:get/get.dart';/// This class is used in the [creative_item_widget] screen.
class CreativeItemModel {Rx<String> titleTxt = Rx("Storyteller");

Rx<String>? id = Rx("");

 }
