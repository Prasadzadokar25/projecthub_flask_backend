import 'package:get/get.dart';/// This class is used in the [faq_item_widget] screen.
class FaqItemModel {Rx<String> groupTxt = Rx("General");

Rx<String>? id = Rx("");

 }
