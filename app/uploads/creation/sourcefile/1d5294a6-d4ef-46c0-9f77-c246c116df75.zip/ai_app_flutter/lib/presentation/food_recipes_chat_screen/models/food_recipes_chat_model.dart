/// This class defines the variables used in the [food_recipes_chat_screen],
/// and is typically used to hold data that is passed between different parts of the application.
class FoodRecipesChatModel { }
