import 'package:ai_app_flutter/core/app_export.dart';import 'package:ai_app_flutter/presentation/home_one_page/models/home_one_model.dart';class HomeOneController extends GetxController {HomeOneController(this.homeOneModelObj);

Rx<HomeOneModel> homeOneModelObj;

@override void onReady() { super.onReady(); } 
@override void onClose() { super.onClose(); } 
 }
