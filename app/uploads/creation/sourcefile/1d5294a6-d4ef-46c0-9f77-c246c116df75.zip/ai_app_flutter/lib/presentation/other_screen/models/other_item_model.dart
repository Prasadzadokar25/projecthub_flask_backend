import 'package:get/get.dart';/// This class is used in the [other_item_widget] screen.
class OtherItemModel {Rx<String> createconversaiTxt = Rx("Create conversaion");

Rx<String>? id = Rx("");

 }
