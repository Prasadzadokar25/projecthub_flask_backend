import 'package:get/get.dart';/// This class is used in the [search_item_widget] screen.
class SearchItemModel {Rx<String> datatypeTxt = Rx("Sed ut perspiciatis unde omnis");

Rx<String>? id = Rx("");

 }
