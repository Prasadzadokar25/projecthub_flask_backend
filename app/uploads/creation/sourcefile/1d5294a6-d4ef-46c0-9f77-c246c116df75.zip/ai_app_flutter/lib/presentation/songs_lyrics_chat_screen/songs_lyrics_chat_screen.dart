import 'package:ai_app_flutter/core/app_export.dart';
import 'package:ai_app_flutter/core/utils/validation_functions.dart';
import 'package:ai_app_flutter/widgets/app_bar/appbar_image.dart';
import 'package:ai_app_flutter/widgets/app_bar/appbar_title.dart';
import 'package:ai_app_flutter/widgets/app_bar/custom_app_bar.dart';
import 'package:ai_app_flutter/widgets/custom_floating_button.dart';
import 'package:ai_app_flutter/widgets/custom_text_form_field.dart';
import 'package:flutter/material.dart';

import 'controller/songs_lyrics_chat_controller.dart';

// ignore_for_file: must_be_immutable
class SongsLyricsChatScreen extends GetWidget<SongsLyricsChatController> {
  GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        resizeToAvoidBottomInset: false,
        backgroundColor: ColorConstant.whiteA700,
        appBar: CustomAppBar(
            height: getVerticalSize(65),
            leadingWidth: 44,
            leading: AppbarImage(
                height: getSize(24),
                width: getSize(24),
                svgPath: ImageConstant.imgArrowleft,
                margin: getMargin(left: 20, top: 21, bottom: 20),
                onTap: () {
                  onTapArrowleft14();
                }),
            centerTitle: true,
            title: AppbarTitle(text: "lbl_songs_lyrics2".tr),
            styleType: Style.bgFillWhiteA700),
        body: SafeArea(
          child: Form(
              key: _formKey,
              child: Container(
                  width: double.maxFinite,
                  margin: getMargin(top: 24),
                  padding: getPadding(left: 20, right: 20),
                  child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        CustomTextFormField(
                            focusNode: FocusNode(),
                            autofocus: true,
                            controller: controller.nameController,
                            hintText: "msg_how_can_i_find_a".tr,
                            margin: getMargin(left: 88),
                            variant: TextFormFieldVariant.FillBlack900,
                            shape: TextFormFieldShape.CustomBorderTL20,
                            padding: TextFormFieldPadding.PaddingAll13,
                            fontStyle: TextFormFieldFontStyle
                                .AirbnbCerealWMd16WhiteA700,
                            alignment: Alignment.centerRight,
                            validator: (value) {
                              if (!isText(value)) {
                                return "Please enter valid text";
                              }
                              return null;
                            }),
                        Container(
                            margin: getMargin(top: 24, right: 81),
                            padding: getPadding(left: 14, right: 14),
                            decoration: AppDecoration.fillGray100a0.copyWith(
                                borderRadius:
                                    BorderRadiusStyle.customBorderTL20),
                            child: Column(
                                mainAxisSize: MainAxisSize.min,
                                mainAxisAlignment: MainAxisAlignment.end,
                                children: [
                                  Container(
                                      width: getHorizontalSize(262),
                                      margin: getMargin(top: 13),
                                      child: Text(
                                          "msg_shazam_will_identify".tr,
                                          maxLines: null,
                                          textAlign: TextAlign.left,
                                          style: AppStyle.txtBody.copyWith(
                                              letterSpacing:
                                                  getHorizontalSize(0.16))))
                                ]))
                      ]))),
        ),
        bottomNavigationBar: Container(
            margin: getMargin(left: 20, right: 92, bottom: 56),
            decoration: AppDecoration.outlineGray100,
            child: Row(mainAxisSize: MainAxisSize.min, children: [
              Expanded(
                  child: CustomTextFormField(
                      focusNode: FocusNode(),
                      autofocus: true,
                      controller: controller.groupsixController,
                      hintText: "msg_ask_me_anything".tr,
                      textInputAction: TextInputAction.done))
            ])),
        floatingActionButton: CustomFloatingButton(
            height: 56,
            width: 56,
            child: CustomImageView(
                svgPath: ImageConstant.imgIcsend,
                height: getVerticalSize(28.0),
                width: getHorizontalSize(28.0))));
  }

  onTapArrowleft14() {
    Get.back();
  }
}
