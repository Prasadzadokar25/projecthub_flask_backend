import 'package:get/get.dart';/// This class is used in the [writing_item_widget] screen.
class WritingItemModel {Rx<String> writeanarticlesTxt = Rx("Write an Articles");

Rx<String>? id = Rx("");

 }
