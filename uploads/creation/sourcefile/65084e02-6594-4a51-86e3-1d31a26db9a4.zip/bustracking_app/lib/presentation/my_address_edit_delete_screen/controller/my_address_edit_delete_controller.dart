import 'package:bustrackingapp/core/app_export.dart';import 'package:bustrackingapp/presentation/my_address_edit_delete_screen/models/my_address_edit_delete_model.dart';/// A controller class for the MyAddressEditDeleteScreen.
///
/// This class manages the state of the MyAddressEditDeleteScreen, including the
/// current myAddressEditDeleteModelObj
class MyAddressEditDeleteController extends GetxController {Rx<MyAddressEditDeleteModel> myAddressEditDeleteModelObj = MyAddressEditDeleteModel().obs;

 }
