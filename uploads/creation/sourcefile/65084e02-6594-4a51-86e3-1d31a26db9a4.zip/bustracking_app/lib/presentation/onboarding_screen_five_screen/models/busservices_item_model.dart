import 'package:get/get.dart';/// This class is used in the [busservices_item_widget] screen.
class BusservicesItemModel {Rx<String>? id = Rx("");

 }
