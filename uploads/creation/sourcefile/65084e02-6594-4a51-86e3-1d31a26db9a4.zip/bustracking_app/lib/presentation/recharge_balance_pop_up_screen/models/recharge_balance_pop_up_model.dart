/// This class defines the variables used in the [recharge_balance_pop_up_screen],
/// and is typically used to hold data that is passed between different parts of the application.
class RechargeBalancePopUpModel { }
