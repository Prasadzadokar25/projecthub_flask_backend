import 'package:get/get.dart';/// This class is used in the [refund_package_item_widget] screen.
class RefundPackageItemModel {Rx<String>? id = Rx("");


String? passValidation;
String? price;

RefundPackageItemModel({this.passValidation, this.price});
 }



