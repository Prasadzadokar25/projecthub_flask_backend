import 'package:bustrackingapp/core/app_export.dart';import 'package:bustrackingapp/presentation/refund_ticket_page/models/refund_ticket_model.dart';/// A controller class for the RefundTicketPage.
///
/// This class manages the state of the RefundTicketPage, including the
/// current refundTicketModelObj
class RefundTicketController extends GetxController {RefundTicketController(this.refundTicketModelObj);

Rx<RefundTicketModel> refundTicketModelObj;

 }
