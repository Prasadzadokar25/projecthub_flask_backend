package com.flutterbekeryapp.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
