import 'package:flutterbekeryapp/core/app_export.dart';

class ApiClient extends GetConnect {}
