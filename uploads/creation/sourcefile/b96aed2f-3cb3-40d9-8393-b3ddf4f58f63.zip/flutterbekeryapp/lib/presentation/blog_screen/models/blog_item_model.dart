
/// This class is used in the [blog_item_widget] screen.

class BlogItemModel {
 String? image;
 String? title;
 String? subTitle;
 String? date;
 String? time;
 BlogItemModel(this.image,this.title,this.subTitle,this.date,this.time);
}
