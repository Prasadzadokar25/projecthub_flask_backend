

/// This class is used in the [cupcake_item_widget] screen.

class CupcakeItemModel {
  String? image;
  String? title;
  CupcakeItemModel(this.image,this.title);
}
