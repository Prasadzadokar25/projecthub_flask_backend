class MyOrderItemModel{
  String? id;
  String? time;
  String? date;
  String? status;
  MyOrderItemModel(this.id,this.time,this.date,this.status);
}