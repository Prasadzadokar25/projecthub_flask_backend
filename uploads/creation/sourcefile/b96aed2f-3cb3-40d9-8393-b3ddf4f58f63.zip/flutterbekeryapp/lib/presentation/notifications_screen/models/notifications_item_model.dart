
/// This class is used in the [notifications_item_widget] screen.

class NotificationsItemModel {


  String? title;
  String? msg;
  String? time;
  NotificationsItemModel(this.title,this.msg,this.time);
}
