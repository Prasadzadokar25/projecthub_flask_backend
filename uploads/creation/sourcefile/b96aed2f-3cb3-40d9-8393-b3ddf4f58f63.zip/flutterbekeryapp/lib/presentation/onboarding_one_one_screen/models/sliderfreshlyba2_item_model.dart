import 'package:get/get.dart';/// This class is used in the [sliderfreshlyba2_item_widget] screen.
class Sliderfreshlyba2ItemModel {Rx<String>? id = Rx("");

 }
