import 'package:get/get.dart';/// This class is used in the [productdetails4_item_widget] screen.
class Productdetails4ItemModel {Rx<String> chocolatecakeTxt = Rx("Rainbow cup cake");

Rx<String>? id = Rx("");

 }
