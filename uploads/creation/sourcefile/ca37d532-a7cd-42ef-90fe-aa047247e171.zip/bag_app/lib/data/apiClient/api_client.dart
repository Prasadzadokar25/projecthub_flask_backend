import 'package:bag_app/core/app_export.dart';

class ApiClient extends GetConnect {}
