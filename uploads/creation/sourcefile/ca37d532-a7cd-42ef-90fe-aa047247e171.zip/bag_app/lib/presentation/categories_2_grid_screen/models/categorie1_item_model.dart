import 'package:get/get.dart';/// This class is used in the [categorie1_item_widget] screen.
class Categorie1ItemModel {Rx<String> cakeTextTxt = Rx("Cake");

Rx<String>? id = Rx("");

 }
