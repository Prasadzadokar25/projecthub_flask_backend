
/// This class is used in the [cupcake_item_widget] screen.

class LaptopBagItemModel {
 String? image;
 String? title;
 LaptopBagItemModel(this.image,this.title);
}
