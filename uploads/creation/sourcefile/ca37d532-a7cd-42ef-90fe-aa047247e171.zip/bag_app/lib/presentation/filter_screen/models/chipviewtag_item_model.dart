import 'package:get/get.dart';/// This class is used in the [chipviewtag_item_widget] screen.
class ChipviewtagItemModel {Rx<String> tagTxt = Rx("Best Seller");

Rx<bool> isSelected = Rx(false);

 }
