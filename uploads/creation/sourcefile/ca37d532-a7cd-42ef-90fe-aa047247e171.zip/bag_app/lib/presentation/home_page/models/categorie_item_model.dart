import 'package:get/get.dart';/// This class is used in the [categorie_item_widget] screen.
class CategorieItemModel {Rx<String> cakeTextTxt = Rx("Cake");

Rx<String>? id = Rx("");

 }
