class DiscountItemModel{
  String? image;
  String? title;
  String? subtitle;
  DiscountItemModel(this.image,this.title,this.subtitle);
}