
/// This class is used in the [slidercar_item_widget] screen.

class SlidercarItemModel {
  String? image;
  String? title;
  SlidercarItemModel(this.image,this.title);
}
