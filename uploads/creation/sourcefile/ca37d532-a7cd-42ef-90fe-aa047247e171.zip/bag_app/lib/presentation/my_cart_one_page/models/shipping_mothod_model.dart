class ShippingModel{
  String? nameOfShipping;
  int? id;
  ShippingModel(this.nameOfShipping,this.id);
}