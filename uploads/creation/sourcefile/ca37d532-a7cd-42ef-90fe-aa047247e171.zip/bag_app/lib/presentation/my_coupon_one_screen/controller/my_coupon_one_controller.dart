import 'package:bag_app/core/app_export.dart';import 'package:bag_app/presentation/my_coupon_one_screen/models/my_coupon_one_model.dart';/// A controller class for the MyCouponOneScreen.
///
/// This class manages the state of the MyCouponOneScreen, including the
/// current myCouponOneModelObj
class MyCouponOneController extends GetxController {Rx<MyCouponOneModel> myCouponOneModelObj = MyCouponOneModel().obs;

 }
