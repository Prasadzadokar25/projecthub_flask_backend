import 'package:get/get.dart';/// This class is used in the [product_item_widget] screen.
class ProductItemModel {Rx<String> productNameTxt = Rx("Rainbow Cupcake");

Rx<String> priceTxt = Rx("90.00");

Rx<String>? id = Rx("");

 }
