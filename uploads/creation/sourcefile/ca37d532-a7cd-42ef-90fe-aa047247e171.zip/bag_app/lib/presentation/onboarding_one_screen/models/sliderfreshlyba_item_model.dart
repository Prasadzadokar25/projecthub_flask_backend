
/// This class is used in the [sliderfreshlyba_item_widget] screen.

class SliderfreshlybaItemModel {
 String? image;
 String? title;
 String? subtitle;
 SliderfreshlybaItemModel(this.image,this.title,this.subtitle);
}
